package banking;

public class ShariahAccount extends BankAccount {

	public ShariahAccount(int accountNumber, String accountHolder, double openingBalance) {
		super(accountNumber, accountHolder, openingBalance);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void deductFees() {
		// TODO Auto-generated method stub
		int cTransactions = 0;
		for (int i = 0; i < transactionCount; i++)
			if (transactions.get(i).transactionType == Transaction.DEPOSIT
					|| transactions.get(i).transactionType == Transaction.WITHDRAW)
				cTransactions++;
		withdraw(1.80 * Math.max(0, cTransactions - 5));
	}

	@Override
	public boolean withdraw(double amount) {
		if (balance < amount)
			return false;
		balance -= amount;
		return true;
	}

}
