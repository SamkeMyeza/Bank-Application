package banking;

public class TraditionalAccount extends BankAccount {
	private double interestRate;

	public TraditionalAccount(int accountNumber, String accountHolder, double openingBalance, double interestRate) {
		super(accountNumber, accountHolder, openingBalance);
		this.interestRate = interestRate;
	}
	public void addInterest() {
		deposit(balance * interestRate);
	}

	@Override
	public void deductFees() {
		withdraw(50);
	}

	@Override
	public boolean withdraw(double amount) {
		if (balance - amount < 500)
			return false;
		balance -= amount;
		return true;
	}

}
